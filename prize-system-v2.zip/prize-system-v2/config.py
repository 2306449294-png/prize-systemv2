import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'prize-system-secret-key'
    DATABASE_URL = os.environ.get('DATABASE_URL')
    if DATABASE_URL:
        SQLALCHEMY_DATABASE_URI = DATABASE_URL.replace('postgres://', 'postgresql://')
    else:
        SQLALCHEMY_DATABASE_URI = 'sqlite:///prize_system.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {'pool_recycle': 300, 'pool_pre_ping': True}
    ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME') or 'admin'
    ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD') or 'admin'
    SMTP_HOST = os.environ.get('SMTP_HOST') or 'smtp.exmail.qq.com'
    SMTP_PORT = int(os.environ.get('SMTP_PORT') or 465)
    SMTP_USER = os.environ.get('SMTP_USER') or ''
    SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD') or ''
    MAIL_DEFAULT_SUBJECT = os.environ.get('MAIL_DEFAULT_SUBJECT') or '【奖品领取通知】'
    MAIL_SENDER_NAME = os.environ.get('MAIL_SENDER_NAME') or '公司行政部门'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    UPLOAD_FOLDER = 'static/uploads'
    QR_CODE_FOLDER = 'static/qr_codes'
