# Railway 部署指南

Railway 是一个支持 Python Flask 的云托管平台，提供 PostgreSQL 数据库。

官网：https://railway.app

---

## 前提条件

1. GitHub 账号
2. Railway 账号（可以用 GitHub 直接登录）

---

## 第一步：上传代码到 GitHub

1. 在 GitHub 创建新仓库（比如 `prize-system`）
2. 上传以下文件：
   - app.py
   - config.py
   - models.py
   - requirements.txt
   - .env
   - railway.json
   - nixpacks.toml
   - Procfile
   - templates/ 文件夹（所有 HTML）
   - static/ 文件夹（空的 uploads 和 qr_codes 子文件夹）

---

## 第二步：在 Railway 创建项目

1. 打开 https://railway.app
2. 点击 **New Project**
3. 选择 **Deploy from GitHub repo**
4. 选择你的 `prize-system` 仓库
5. 点击 **Deploy Now**

---

## 第三步：添加 PostgreSQL 数据库

1. 在项目页面，点击 **+ New Service**
2. 选择 **Database** → **PostgreSQL**
3. Railway 会自动创建数据库
4. 点击你的 **Web Service**（不是数据库）
5. 在 **Variables** 标签页，添加变量：
   - **Key**: `DATABASE_URL`
   - **Value**: 点击数据库服务的 **Connect** 标签，复制连接串
6. 点击保存

---

## 第四步：设置环境变量（可选）

在 Web Service 的 **Variables** 标签页，添加：

| 变量名 | 值 | 说明 |
|--------|-----|------|
| `SECRET_KEY` | 随机字符串 | 安全密钥 |
| `ADMIN_USERNAME` | admin | 管理员账号 |
| `ADMIN_PASSWORD` | admin | 管理员密码 |
| `SMTP_HOST` | smtp.exmail.qq.com | 邮件服务器 |
| `SMTP_PORT` | 465 | 邮件端口 |
| `SMTP_USER` | 你的邮箱 | 发件邮箱 |
| `SMTP_PASSWORD` | 授权码 | 邮箱授权码 |

---

## 第五步：重新部署

添加完变量后，Railway 会自动重新部署。如果没有：

1. 点击 Web Service
2. 点击 **Deployments** 标签
3. 点击 **Redeploy**

---

## 第六步：生成域名

1. 点击 Web Service → **Settings** 标签
2. 找到 **Networking** 部分
3. 点击 **Generate Domain**
4. Railway 会分配域名，类似 `xxx.up.railway.app`

---

## 首次使用

1. 打开你的 Railway 域名
2. 用默认账号登录：admin / admin
3. 建议立即修改密码

---

## 后续更新

修改代码后 push 到 GitHub，Railway 会自动重新部署。

---

## 免费额度

| 项目 | 额度 |
|------|------|
| 计算资源 | $5/月 |
| PostgreSQL | 免费 1GB |
| 带宽 | 100 GB/月 |

对于奖品管理系统完全够用。
