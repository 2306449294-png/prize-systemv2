# PythonAnywhere 部署指南

## 第一步：清理旧文件

打开 PythonAnywhere **Consoles** → **Bash**，执行：

```bash
rm -rf ~/prize-system ~/prize-system-deploy ~/prize-system-pa ~/prize_system.db
```

## 第二步：上传代码

1. 打开 PythonAnywhere **Files** 页面
2. 点击 **Upload a file**
3. 上传 `prize-system-v2.zip`

## 第三步：解压并安装依赖

在 Bash 里执行：

```bash
cd ~
unzip prize-system-v2.zip
mv prize-system-v2 prize-system
cd prize-system
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 第四步：初始化数据库

```bash
python -c "from app import app, init_app; app.app_context().push(); init_app()"
```

看到 **"默认管理员已创建: admin / admin"** 说明成功。

## 第五步：创建 Web 应用

1. 点击顶部 **Web** 标签
2. 点击 **Add a new web app**
3. 选择 **Flask**
4. 选择 **Python 3.11**
5. 点击 **Next**

## 第六步：修改 WSGI 配置

1. 点击 WSGI 配置文件链接
2. 全部删掉，替换为：

```python
import sys
path = '/home/nerea666/prize-system'
if path not in sys.path:
    sys.path.insert(0, path)

import os
os.chdir(path)

from app import app as application
```

3. 点击 **Save**

## 第七步：配置静态文件

在 Web 页面 **Static files** 部分：
- URL: `/static/`
- Directory: `/home/nerea666/prize-system/static`
- 点击 **Enter**

## 第八步：Reload

点击 **Reload nerea666.pythonanywhere.com**

## 第九步：访问

浏览器打开：
```
https://nerea666.pythonanywhere.com
```

登录：
- 用户名：`admin`
- 密码：`admin`

---

## 常见问题

### 页面 500 错误

查看 **Error log** 链接，看具体错误信息。

### 修改代码后不生效

必须点击 **Reload** 才会重新加载代码。

### 数据库被锁定

SQLite 不支持并发写入，多人同时操作可能会报错。这是 SQLite 的限制。
