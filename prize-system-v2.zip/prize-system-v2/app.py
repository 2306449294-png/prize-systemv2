import os
import sys
import smtplib
import zipfile
import qrcode
from io import BytesIO
from datetime import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, jsonify, send_file,
    session, redirect, url_for
)
from werkzeug.utils import secure_filename

from models import (
    db, Employee, Activity, Winner, OperationLog,
    User, SystemConfig, generate_unique_code
)
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)


# --------------------------------------------------------------------------
# Helper functions
# --------------------------------------------------------------------------

def api_response(success, data=None, message=''):
    if data is None:
        data = {}
    return jsonify({'success': success, 'data': data, 'message': message})


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': '请先登录'}), 401
        return f(*args, **kwargs)
    return decorated_function


def log_operation(action, detail):
    try:
        user_id = session.get('user_id')
        username = session.get('username', '')
        log = OperationLog(
            user_id=user_id,
            username=username,
            action=action,
            detail=detail
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        print(f"Failed to log operation: {e}")


def generate_qr_code(unique_code, winner_name, prize_name, activity_name):
    qr_dir = os.path.join(app.static_folder, 'qr_codes')
    os.makedirs(qr_dir, exist_ok=True)

    qr_text = unique_code
    img = qrcode.make(qr_text)
    filename = f"{unique_code}.png"
    filepath = os.path.join(qr_dir, filename)
    img.save(filepath)
    return filename


def init_app():
    with app.app_context():
        db.create_all()
        # Create default admin user if not exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                password='admin123',
                role='admin',
                display_name='管理员'
            )
            db.session.add(admin)
            db.session.commit()
            print("Default admin user created (admin / admin123)")

        # Initialize show_employee_no config
        config = SystemConfig.query.filter_by(key='show_employee_no').first()
        if not config:
            config = SystemConfig(key='show_employee_no', value='false')
            db.session.add(config)
            db.session.commit()
            print("Initialized show_employee_no config")


# --------------------------------------------------------------------------
# Before request - ensure static directories exist
# --------------------------------------------------------------------------

@app.before_request
def ensure_static_dirs():
    qr_dir = os.path.join(app.static_folder, 'qr_codes')
    if not os.path.exists(qr_dir):
        os.makedirs(qr_dir, exist_ok=True)


# ==========================================================================
# Page routes
# ==========================================================================

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('index.html')


@app.route('/login')
def login_page():
    if 'user_id' in session:
        return redirect('/')
    return render_template('login.html')


@app.route('/employees')
def employees():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('employees.html')


@app.route('/activities')
def activities():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('activities.html')


@app.route('/winners')
def winners():
    if 'user_id' not in session:
        return redirect('/login')
    activity_id = request.args.get('activity_id')
    return render_template('winners.html', activity_id=activity_id)


@app.route('/qr-codes')
def qr_codes():
    if 'user_id' not in session:
        return redirect('/login')
    activity_id = request.args.get('activity_id')
    return render_template('qr_codes.html', activity_id=activity_id)


@app.route('/email')
def email():
    if 'user_id' not in session:
        return redirect('/login')
    activity_id = request.args.get('activity_id')
    return render_template('email.html', activity_id=activity_id)


@app.route('/scan')
def scan():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('scan.html')


@app.route('/logs')
def logs():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('logs.html')


@app.route('/settings')
def settings():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('settings.html')


# ==========================================================================
# API routes - Auth
# ==========================================================================

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not username or not password:
        return api_response(False, message='用户名和密码不能为空')

    user = User.query.filter_by(username=username).first()
    if not user or user.password != password:
        return api_response(False, message='用户名或密码错误')

    session['user_id'] = user.id
    session['username'] = user.username
    session['role'] = user.role

    user.last_login = datetime.utcnow()
    db.session.commit()

    log_operation('登录', f'用户 {username} 登录系统')
    return api_response(True, data={
        'user': {
            'id': user.id,
            'username': user.username,
            'role': user.role,
            'display_name': user.display_name
        }
    }, message='登录成功')


@app.route('/api/logout', methods=['POST'])
def api_logout():
    username = session.get('username', '')
    session.clear()
    log_operation('登出', f'用户 {username} 退出系统')
    return api_response(True, message='已退出登录')


@app.route('/api/me', methods=['GET'])
@login_required
def api_me():
    user = User.query.get(session['user_id'])
    if not user:
        session.clear()
        return api_response(False, message='用户不存在')
    return api_response(True, data={
        'user': {
            'id': user.id,
            'username': user.username,
            'role': user.role,
            'display_name': user.display_name
        }
    })


# ==========================================================================
# API routes - Employees CRUD
# ==========================================================================

@app.route('/api/employees', methods=['GET'])
@login_required
def api_list_employees():
    employees = Employee.query.order_by(Employee.id.desc()).all()
    return api_response(True, data=[
        {
            'id': e.id,
            'name': e.name,
            'email': e.email,
            'department': e.department,
            'created_at': e.created_at.isoformat() if e.created_at else None
        }
        for e in employees
    ])


@app.route('/api/employees', methods=['POST'])
@login_required
def api_create_employee():
    data = request.get_json()
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    department = data.get('department', '').strip()

    if not name:
        return api_response(False, message='姓名不能为空')

    employee = Employee(name=name, email=email, department=department)
    db.session.add(employee)
    db.session.commit()

    log_operation('创建员工', f'创建员工: {name}')
    return api_response(True, data={'employee': {
        'id': employee.id,
        'name': employee.name,
        'email': employee.email,
        'department': employee.department,
        'created_at': employee.created_at.isoformat() if employee.created_at else None
    }}, message='员工创建成功')


@app.route('/api/employees/<int:emp_id>', methods=['GET'])
@login_required
def api_get_employee(emp_id):
    employee = Employee.query.get(emp_id)
    if not employee:
        return api_response(False, message='员工不存在')
    return api_response(True, data={'employee': {
        'id': employee.id,
        'name': employee.name,
        'email': employee.email,
        'department': employee.department,
        'created_at': employee.created_at.isoformat() if employee.created_at else None
    }})


@app.route('/api/employees/<int:emp_id>', methods=['PUT'])
@login_required
def api_update_employee(emp_id):
    employee = Employee.query.get(emp_id)
    if not employee:
        return api_response(False, message='员工不存在')

    data = request.get_json()
    if 'name' in data:
        employee.name = data['name'].strip()
    if 'email' in data:
        employee.email = data['email'].strip()
    if 'department' in data:
        employee.department = data['department'].strip()

    db.session.commit()
    log_operation('更新员工', f'更新员工: {employee.name}')
    return api_response(True, data={'employee': {
        'id': employee.id,
        'name': employee.name,
        'email': employee.email,
        'department': employee.department,
        'created_at': employee.created_at.isoformat() if employee.created_at else None
    }}, message='员工更新成功')


@app.route('/api/employees/<int:emp_id>', methods=['DELETE'])
@login_required
def api_delete_employee(emp_id):
    employee = Employee.query.get(emp_id)
    if not employee:
        return api_response(False, message='员工不存在')

    name = employee.name
    db.session.delete(employee)
    db.session.commit()

    log_operation('删除员工', f'删除员工: {name}')
    return api_response(True, message='员工删除成功')


# ==========================================================================
# API routes - Activities CRUD
# ==========================================================================

@app.route('/api/activities', methods=['GET'])
@login_required
def api_list_activities():
    activities = Activity.query.order_by(Activity.id.desc()).all()
    return api_response(True, data=[
        {
            'id': a.id,
            'name': a.name,
            'description': a.description,
            'prizes': a.prizes,
            'date': a.date.isoformat() if a.date else None,
            'status': a.status,
            'created_at': a.created_at.isoformat() if a.created_at else None
        }
        for a in activities
    ])


@app.route('/api/activities', methods=['POST'])
@login_required
def api_create_activity():
    data = request.get_json()
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()
    prizes = data.get('prizes', '').strip()
    date_str = data.get('date', '').strip()

    if not name:
        return api_response(False, message='活动名称不能为空')

    activity_date = None
    if date_str:
        try:
            activity_date = datetime.strptime(date_str, '%Y-%m-%d')
        except ValueError:
            return api_response(False, message='日期格式不正确')

    activity = Activity(
        name=name,
        description=description,
        prizes=prizes,
        date=activity_date,
        status='active'
    )
    db.session.add(activity)
    db.session.commit()

    log_operation('创建活动', f'创建活动: {name}')
    return api_response(True, data={'activity': {
        'id': activity.id,
        'name': activity.name,
        'description': activity.description,
        'prizes': activity.prizes,
        'date': activity.date.isoformat() if activity.date else None,
        'status': activity.status,
        'created_at': activity.created_at.isoformat() if activity.created_at else None
    }}, message='活动创建成功')


@app.route('/api/activities/<int:act_id>', methods=['GET'])
@login_required
def api_get_activity(act_id):
    activity = Activity.query.get(act_id)
    if not activity:
        return api_response(False, message='活动不存在')
    return api_response(True, data={'activity': {
        'id': activity.id,
        'name': activity.name,
        'description': activity.description,
        'prizes': activity.prizes,
        'date': activity.date.isoformat() if activity.date else None,
        'status': activity.status,
        'created_at': activity.created_at.isoformat() if activity.created_at else None
    }})


@app.route('/api/activities/<int:act_id>', methods=['PUT'])
@login_required
def api_update_activity(act_id):
    activity = Activity.query.get(act_id)
    if not activity:
        return api_response(False, message='活动不存在')

    data = request.get_json()
    if 'name' in data:
        activity.name = data['name'].strip()
    if 'description' in data:
        activity.description = data['description'].strip()
    if 'prizes' in data:
        activity.prizes = data['prizes'].strip()
    if 'date' in data:
        date_str = data['date'].strip()
        if date_str:
            try:
                activity.date = datetime.strptime(date_str, '%Y-%m-%d')
            except ValueError:
                return api_response(False, message='日期格式不正确')
        else:
            activity.date = None
    if 'status' in data:
        activity.status = data['status']

    db.session.commit()
    log_operation('更新活动', f'更新活动: {activity.name}')
    return api_response(True, data={'activity': {
        'id': activity.id,
        'name': activity.name,
        'description': activity.description,
        'prizes': activity.prizes,
        'date': activity.date.isoformat() if activity.date else None,
        'status': activity.status,
        'created_at': activity.created_at.isoformat() if activity.created_at else None
    }}, message='活动更新成功')


@app.route('/api/activities/<int:act_id>', methods=['DELETE'])
@login_required
def api_delete_activity(act_id):
    activity = Activity.query.get(act_id)
    if not activity:
        return api_response(False, message='活动不存在')

    name = activity.name
    db.session.delete(activity)
    db.session.commit()

    log_operation('删除活动', f'删除活动: {name}')
    return api_response(True, message='活动删除成功')


# ==========================================================================
# API routes - Winners per activity
# ==========================================================================

@app.route('/api/activities/<int:act_id>/winners', methods=['GET'])
@login_required
def api_list_activity_winners(act_id):
    activity = Activity.query.get(act_id)
    if not activity:
        return api_response(False, message='活动不存在')

    winners = Winner.query.filter_by(activity_id=act_id).order_by(Winner.id.desc()).all()
    return api_response(True, data=[
        {
            'id': w.id,
            'activity_id': w.activity_id,
            'name': w.name,
            'email': w.email,
            'department': w.department,
            'prize_name': w.prize_name,
            'unique_code': w.unique_code,
            'qr_code_path': w.qr_code_path,
            'is_verified': w.is_verified,
            'verified_at': w.verified_at.isoformat() if w.verified_at else None,
            'email_sent': w.email_sent,
            'email_sent_at': w.email_sent_at.isoformat() if w.email_sent_at else None,
            'created_at': w.created_at.isoformat() if w.created_at else None
        }
        for w in winners
    ])


@app.route('/api/activities/<int:act_id>/winners', methods=['POST'])
@login_required
def api_create_activity_winner(act_id):
    activity = Activity.query.get(act_id)
    if not activity:
        return api_response(False, message='活动不存在')

    data = request.get_json()
    name = data.get('name', '').strip()
    prize_name = data.get('prize_name', '').strip()

    if not name:
        return api_response(False, message='获奖人姓名不能为空')
    if not prize_name:
        return api_response(False, message='奖品名称不能为空')

    # Auto-fill email/department by matching name against Employee table
    email = data.get('email', '').strip()
    department = data.get('department', '').strip()

    if not email or not department:
        employee = Employee.query.filter_by(name=name).first()
        if employee:
            if not email:
                email = employee.email or ''
            if not department:
                department = employee.department or ''

    unique_code = generate_unique_code()
    winner = Winner(
        activity_id=act_id,
        name=name,
        email=email,
        department=department,
        prize_name=prize_name,
        unique_code=unique_code,
        is_verified=False,
        email_sent=False
    )

    # Generate QR code
    try:
        qr_filename = generate_qr_code(
            unique_code, name, prize_name, activity.name
        )
        winner.qr_code_path = qr_filename
    except Exception as e:
        print(f"QR code generation failed: {e}")

    db.session.add(winner)
    db.session.commit()

    log_operation('添加获奖人', f'活动 {activity.name} 添加获奖人: {name} - {prize_name}')
    return api_response(True, data={'winner': {
        'id': winner.id,
        'activity_id': winner.activity_id,
        'name': winner.name,
        'email': winner.email,
        'department': winner.department,
        'prize_name': winner.prize_name,
        'unique_code': winner.unique_code,
        'qr_code_path': winner.qr_code_path,
        'is_verified': winner.is_verified,
        'verified_at': None,
        'email_sent': winner.email_sent,
        'email_sent_at': None,
        'created_at': winner.created_at.isoformat() if winner.created_at else None
    }}, message='获奖人添加成功')


# ==========================================================================
# API routes - Winners CRUD (individual)
# ==========================================================================

@app.route('/api/winners', methods=['GET'])
@login_required
def api_list_winners():
    winners = Winner.query.order_by(Winner.id.desc()).all()
    return api_response(True, data=[
        {
            'id': w.id,
            'activity_id': w.activity_id,
            'name': w.name,
            'email': w.email,
            'department': w.department,
            'prize_name': w.prize_name,
            'unique_code': w.unique_code,
            'qr_code_path': w.qr_code_path,
            'is_verified': w.is_verified,
            'verified_at': w.verified_at.isoformat() if w.verified_at else None,
            'email_sent': w.email_sent,
            'email_sent_at': w.email_sent_at.isoformat() if w.email_sent_at else None,
            'created_at': w.created_at.isoformat() if w.created_at else None
        }
        for w in winners
    ])


@app.route('/api/winners/<int:winner_id>', methods=['GET'])
@login_required
def api_get_winner(winner_id):
    winner = Winner.query.get(winner_id)
    if not winner:
        return api_response(False, message='获奖记录不存在')
    return api_response(True, data={'winner': {
        'id': winner.id,
        'activity_id': winner.activity_id,
        'name': winner.name,
        'email': winner.email,
        'department': winner.department,
        'prize_name': winner.prize_name,
        'unique_code': winner.unique_code,
        'qr_code_path': winner.qr_code_path,
        'is_verified': winner.is_verified,
        'verified_at': winner.verified_at.isoformat() if winner.verified_at else None,
        'email_sent': winner.email_sent,
        'email_sent_at': winner.email_sent_at.isoformat() if winner.email_sent_at else None,
        'created_at': winner.created_at.isoformat() if winner.created_at else None
    }})


@app.route('/api/winners/<int:winner_id>', methods=['PUT'])
@login_required
def api_update_winner(winner_id):
    winner = Winner.query.get(winner_id)
    if not winner:
        return api_response(False, message='获奖记录不存在')

    data = request.get_json()
    if 'name' in data:
        winner.name = data['name'].strip()
    if 'prize_name' in data:
        winner.prize_name = data['prize_name'].strip()
    if 'email' in data:
        winner.email = data['email'].strip()
    if 'department' in data:
        winner.department = data['department'].strip()
    if 'is_verified' in data:
        winner.is_verified = data['is_verified']

    db.session.commit()
    log_operation('更新获奖人', f'更新获奖记录: {winner.name} - {winner.prize_name}')
    return api_response(True, data={'winner': {
        'id': winner.id,
        'activity_id': winner.activity_id,
        'name': winner.name,
        'email': winner.email,
        'department': winner.department,
        'prize_name': winner.prize_name,
        'unique_code': winner.unique_code,
        'qr_code_path': winner.qr_code_path,
        'is_verified': winner.is_verified,
        'verified_at': winner.verified_at.isoformat() if winner.verified_at else None,
        'email_sent': winner.email_sent,
        'email_sent_at': winner.email_sent_at.isoformat() if winner.email_sent_at else None,
        'created_at': winner.created_at.isoformat() if winner.created_at else None
    }}, message='获奖记录更新成功')


@app.route('/api/winners/<int:winner_id>', methods=['DELETE'])
@login_required
def api_delete_winner(winner_id):
    winner = Winner.query.get(winner_id)
    if not winner:
        return api_response(False, message='获奖记录不存在')

    name = winner.name
    db.session.delete(winner)
    db.session.commit()

    log_operation('删除获奖人', f'删除获奖记录: {name}')
    return api_response(True, message='获奖记录删除成功')


# ==========================================================================
# API routes - QR Codes
# ==========================================================================

@app.route('/api/qr-codes', methods=['GET'])
@login_required
def api_list_qr_codes():
    winners = Winner.query.order_by(Winner.id.desc()).all()
    result = []
    for w in winners:
        if w.qr_code_path:
            result.append({
                'winner_id': w.id,
                'name': w.name,
                'prize_name': w.prize_name,
                'unique_code': w.unique_code,
                'qr_code_path': w.qr_code_path,
                'is_verified': w.is_verified
            })
    return api_response(True, data=result)


@app.route('/api/qr-codes/<filename>/download', methods=['GET'])
@login_required
def api_download_qr_code(filename):
    qr_dir = os.path.join(app.static_folder, 'qr_codes')
    filepath = os.path.join(qr_dir, filename)
    if not os.path.exists(filepath):
        return api_response(False, message='二维码文件不存在')
    return send_file(filepath, as_attachment=True, download_name=filename)


# ==========================================================================
# API routes - Email
# ==========================================================================

@app.route('/api/email/send', methods=['POST'])
@login_required
def api_send_email():
    data = request.get_json()
    winner_ids = data.get('winner_ids', [])
    smtp_config = data.get('smtp_config', {})

    if not winner_ids:
        return api_response(False, message='请选择获奖人')

    # Get SMTP config from SystemConfig if not provided
    if not smtp_config:
        smtp_config = {}
        for key in ['smtp_host', 'smtp_port', 'smtp_user', 'smtp_password', 'smtp_from_name']:
            config = SystemConfig.query.filter_by(key=key).first()
            if config:
                smtp_config[key] = config.value

    host = smtp_config.get('smtp_host', '')
    port = int(smtp_config.get('smtp_port', 587))
    user = smtp_config.get('smtp_user', '')
    password = smtp_config.get('smtp_password', '')
    from_name = smtp_config.get('smtp_from_name', '系统通知')

    if not host or not user:
        return api_response(False, message='SMTP配置不完整，请先在系统设置中配置')

    winners = Winner.query.filter(Winner.id.in_(winner_ids)).all()
    if not winners:
        return api_response(False, message='未找到获奖记录')

    success_count = 0
    fail_count = 0

    try:
        server = smtplib.SMTP(host, port, timeout=10)
        server.starttls()
        server.login(user, password)

        for winner in winners:
            if not winner.email:
                fail_count += 1
                continue

            activity = Activity.query.get(winner.activity_id)
            activity_name = activity.name if activity else '未知活动'

            subject = f'恭喜您获得 {activity_name} - {winner.prize_name}'
            body = f"""尊敬的 {winner.name}：

恭喜您在 "{activity_name}" 中获得了 "{winner.prize_name}"！

您的唯一兑奖码为：{winner.unique_code}

请凭此兑奖码在活动现场领取您的奖品。

祝您愉快！
"""
            from email.mime.text import MIMEText
            msg = MIMEText(body, 'plain', 'utf-8')
            msg['Subject'] = subject
            msg['From'] = f'{from_name} <{user}>'
            msg['To'] = winner.email

            try:
                server.sendmail(user, [winner.email], msg.as_string())
                winner.email_sent = True
                winner.email_sent_at = datetime.utcnow()
                success_count += 1
            except Exception as e:
                print(f"Failed to send email to {winner.email}: {e}")
                fail_count += 1

        server.quit()
        db.session.commit()

    except Exception as e:
        return api_response(False, message=f'邮件发送失败: {str(e)}')

    log_operation('发送邮件', f'发送 {success_count} 封邮件, 失败 {fail_count} 封')
    return api_response(True, message=f'成功发送 {success_count} 封邮件, 失败 {fail_count} 封')


# ==========================================================================
# API routes - Scan (no login required)
# ==========================================================================

@app.route('/api/scan', methods=['POST'])
def api_scan():
    data = request.get_json()
    unique_code = data.get('unique_code', '').strip()

    if not unique_code:
        return api_response(False, message='请提供兑奖码')

    winner = Winner.query.filter_by(unique_code=unique_code).first()
    if not winner:
        return api_response(False, message='无效的兑奖码')

    if winner.is_verified:
        return api_response(False, message='该兑奖码已被核验，请勿重复兑奖')

    winner.is_verified = True
    winner.verified_at = datetime.utcnow()
    db.session.commit()

    log_operation('核验兑奖', f'核验兑奖码 {unique_code}: {winner.name} - {winner.prize_name}')
    return api_response(True, data={
        'name': winner.name,
        'prize_name': winner.prize_name,
        'email': winner.email,
        'department': winner.department,
        'is_verified': True,
        'verified_at': winner.verified_at.isoformat() if winner.verified_at else None
    }, message='核验成功')


# ==========================================================================
# API routes - Logs
# ==========================================================================

@app.route('/api/logs', methods=['GET'])
@login_required
def api_list_logs():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)

    pagination = OperationLog.query.order_by(
        OperationLog.created_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)

    logs = pagination.items
    return api_response(True, data={
        'logs': [
            {
                'id': log.id,
                'user_id': log.user_id,
                'username': log.username,
                'action': log.action,
                'detail': log.detail,
                'created_at': log.created_at.isoformat() if log.created_at else None
            }
            for log in logs
        ],
        'total': pagination.total,
        'page': pagination.page,
        'per_page': pagination.per_page,
        'pages': pagination.pages
    })


# ==========================================================================
# API routes - System clear
# ==========================================================================

@app.route('/api/system/clear', methods=['POST'])
@login_required
def api_system_clear():
    if session.get('role') != 'admin':
        return api_response(False, message='仅管理员可执行此操作')

    data = request.get_json()
    target = data.get('target', '')

    if target == 'employees':
        Employee.query.delete()
        log_operation('系统清理', '清空所有员工数据')
    elif target == 'activities':
        Activity.query.delete()
        log_operation('系统清理', '清空所有活动数据')
    elif target == 'winners':
        Winner.query.delete()
        log_operation('系统清理', '清空所有获奖数据')
    elif target == 'logs':
        OperationLog.query.delete()
        log_operation('系统清理', '清空所有操作日志')
    elif target == 'all':
        Winner.query.delete()
        Activity.query.delete()
        Employee.query.delete()
        OperationLog.query.delete()
        log_operation('系统清理', '清空所有数据')
    else:
        return api_response(False, message='无效的清理目标')

    db.session.commit()
    return api_response(True, message='数据清理成功')


# ==========================================================================
# API routes - Users CRUD (admin only)
# ==========================================================================

@app.route('/api/users', methods=['GET'])
@login_required
def api_list_users():
    if session.get('role') != 'admin':
        return api_response(False, message='仅管理员可查看用户列表')

    users = User.query.order_by(User.id.asc()).all()
    return api_response(True, data=[
        {
            'id': u.id,
            'username': u.username,
            'role': u.role,
            'display_name': u.display_name,
            'last_login': u.last_login.isoformat() if u.last_login else None,
            'created_at': u.created_at.isoformat() if u.created_at else None
        }
        for u in users
    ])


@app.route('/api/users', methods=['POST'])
@login_required
def api_create_user():
    if session.get('role') != 'admin':
        return api_response(False, message='仅管理员可创建用户')

    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    role = data.get('role', 'user').strip()
    display_name = data.get('display_name', '').strip()

    if not username or not password:
        return api_response(False, message='用户名和密码不能为空')

    existing = User.query.filter_by(username=username).first()
    if existing:
        return api_response(False, message='用户名已存在')

    user = User(
        username=username,
        password=password,
        role=role,
        display_name=display_name or username
    )
    db.session.add(user)
    db.session.commit()

    log_operation('创建用户', f'创建用户: {username}')
    return api_response(True, data={'user': {
        'id': user.id,
        'username': user.username,
        'role': user.role,
        'display_name': user.display_name,
        'last_login': None,
        'created_at': user.created_at.isoformat() if user.created_at else None
    }}, message='用户创建成功')


@app.route('/api/users/<int:user_id>', methods=['PUT'])
@login_required
def api_update_user(user_id):
    if session.get('role') != 'admin':
        return api_response(False, message='仅管理员可修改用户')

    user = User.query.get(user_id)
    if not user:
        return api_response(False, message='用户不存在')

    data = request.get_json()
    if 'password' in data and data['password']:
        user.password = data['password']
    if 'role' in data:
        user.role = data['role']
    if 'display_name' in data:
        user.display_name = data['display_name']

    db.session.commit()
    log_operation('更新用户', f'更新用户: {user.username}')
    return api_response(True, data={'user': {
        'id': user.id,
        'username': user.username,
        'role': user.role,
        'display_name': user.display_name,
        'last_login': user.last_login.isoformat() if user.last_login else None,
        'created_at': user.created_at.isoformat() if user.created_at else None
    }}, message='用户更新成功')


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@login_required
def api_delete_user(user_id):
    if session.get('role') != 'admin':
        return api_response(False, message='仅管理员可删除用户')

    user = User.query.get(user_id)
    if not user:
        return api_response(False, message='用户不存在')

    if user.role == 'admin':
        # Don't allow deleting the last admin
        admin_count = User.query.filter_by(role='admin').count()
        if admin_count <= 1:
            return api_response(False, message='不能删除最后一个管理员账户')

    username = user.username
    db.session.delete(user)
    db.session.commit()

    log_operation('删除用户', f'删除用户: {username}')
    return api_response(True, message='用户删除成功')


# ==========================================================================
# API routes - Config
# ==========================================================================

@app.route('/api/config', methods=['GET'])
@login_required
def api_get_config():
    configs = SystemConfig.query.all()
    result = {}
    for c in configs:
        result[c.key] = c.value
    return api_response(True, data=result)


@app.route('/api/config', methods=['POST'])
@login_required
def api_update_config():
    if session.get('role') != 'admin':
        return api_response(False, message='仅管理员可修改系统配置')

    data = request.get_json()
    updated = []
    for key, value in data.items():
        config = SystemConfig.query.filter_by(key=key).first()
        if config:
            config.value = str(value)
        else:
            config = SystemConfig(key=key, value=str(value))
            db.session.add(config)
        updated.append(key)

    db.session.commit()
    log_operation('更新配置', f'更新系统配置: {", ".join(updated)}')
    return api_response(True, message='系统配置更新成功')


# ==========================================================================
# Main
# ==========================================================================

if __name__ == '__main__':
    init_app()
    import webbrowser
    webbrowser.open('http://localhost:8080')
    app.run(host='0.0.0.0', port=8080)